#!/bin/sh
# mtlm-router appliance — start the server (no systemd needed).
# Env knobs: PORT (8097), ANVIL_ROUTE_MINCONF (0.55), ANVIL_GATE_MINCONF,
# ANVIL_POOL=max|mean, ANVIL_LOG (decisions.jsonl),
# ANVIL_DELEGATE_URL/KEY/MODEL/SYS (optional upstream for delegated requests).
cd "$(dirname "$0")"
PORT=${PORT:-8097}
export ANVIL_TOOLS_INJECT=0
export ANVIL_HEAD=models/mairie_mt3.head ANVIL_EXPERTS=mairie_c:models/mairie_mt3c.head
export ANVIL_LOG=logs/decisions.jsonl
mkdir -p logs
echo "mtlm-router on http://0.0.0.0:$PORT  (logs: logs/decisions.jsonl)"
exec ./anvil-serve models/model.bin "$PORT"
