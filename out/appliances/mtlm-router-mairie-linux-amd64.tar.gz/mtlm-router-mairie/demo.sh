#!/bin/sh
# mtlm-router "mairie" — 60-second vendor demo.
# Boots the appliance, fires a representative battery, prints the typed
# decision (route + confidence + complexity tier) for each.
cd "$(dirname "$0")"
PORT=8097
./start.sh $PORT > demo.log 2>&1 &
PID=$!
trap 'kill $PID 2>/dev/null' EXIT
sleep 3

ask() {
  R=$(curl -s localhost:$PORT/v1/route -H 'Content-Type: application/json' \
        -d "{\"messages\":[{\"role\":\"user\",\"content\":\"$1\"}]}")
  echo "$R" | python3 -c "
import json,sys
d=json.load(sys.stdin)
print('  -> %-22s conf=%.2f  tier=%s  action=%s' % (
    d['route'], d['confidence'], d.get('tier','-'), d['action']))"
}

echo '=== mtlm-router mairie demo ==='
echo
echo '[clear in-domain request (agent-transcribed style) — auto-routes]'
printf 'Dotation de bacs. Je souhaite obtenir un bac jaune supplementaire\n'; ask "Dotation de bacs. Je souhaite obtenir un bac jaune supplementaire"
printf 'Depot illicite. Des encombrants ont ete abandonnes rue des Lilas\n'; ask "Depot illicite. Des encombrants ont ete abandonnes rue des Lilas"
echo
echo '[free-form citizen phrasing — abstains rather than guess]'
printf 'mon bac vert n a pas ete ramasse ce matin\n'; ask "mon bac vert n a pas ete ramasse ce matin"
echo
echo '[near-domain but out of scope — escalates to human, no misroute]'
printf 'je veux faire renouveler mon passeport\n'; ask "je veux faire renouveler mon passeport"
printf 'quels sont les horaires de la piscine municipale\n'; ask "quels sont les horaires de la piscine municipale"
echo
echo 'Done. Raw API: curl localhost:'$PORT'/v1/route -d "{\"messages\":[{\"role\":\"user\",\"content\":\"...\"}]}"'
echo 'Optional escalate signal: ANVIL_WITH_NOUL=1 ./start.sh  (experimental)'
