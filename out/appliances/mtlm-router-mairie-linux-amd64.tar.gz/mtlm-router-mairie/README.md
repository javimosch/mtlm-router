# mtlm-router "mairie" — municipal request triage appliance

Self-hosted typed decision layer for collectivite request inboxes
(dechets: collecte, dotation, depot sauvage, colonnes d apport...).

## Requirements

- Linux x86-64, glibc, libssl3 (stock Debian/Ubuntu/RHEL works)
- ~30MB disk, <512MB RAM, no GPU
- `curl` + `python3` for demo.sh pretty-printing (optional)

## Install & run

Everything needed is in this tarball — the anvil-serve binary, the model
(models/model.bin), the tokenizer, and the head files. Nothing to install,
no model download, no external calls, no license server.

    tar xzf mtlm-router-mairie-linux-amd64.tar.gz
    cd mtlm-router-mairie
    ./start.sh            # listens on :8097
    ./start.sh 8080       # custom port
    ./demo.sh             # boots + fires a demo battery

## Use

    curl localhost:8097/v1/route -d "{\"state\":\"ma poubelle n a pas ete ramassee\"}"
    # -> {"route":"collecte_om","confidence":...,"action":"tool_call"|"delegate"}

  action=tool_call  -> confident, auto-route it
  action=delegate   -> human/agent fallback (ambiguous or off-domain)

## Compound signals (one call, same latency)

  {"route":..., "confidence":..., "tier":"1"-"4" complexity}

Optional experimental escalate signal: ANVIL_WITH_NOUL=1 ./start.sh adds
"p_yes" to the response. WARNING: noul was tuned on a different vocabulary —
on municipal French it over-fires and would block auto-routing. Treat it as
a signal to validate on your traffic, not a production gate.

## Routes (15)

agents autres changement_bacs collecte_bio collecte_encombrant collecte_om
collecte_selective colonne_apport compostage conteneurs_enterres dechetterie
depot_illicite dotation_bacs positionnement_bacs sacs + escalate

Measured on a real production export (6,402 labeled requests, 15 routes):
82.5% holdout accuracy (multi-tap head, concat of 3 pooled hidden-state
taps), ~0% confident-wrong (rest abstain), 51KB head,
~200ms CPU per decision. No GPU, no cloud calls — data never leaves the box.

## Honest limits

- Novel/informal phrasings tend to abstain (delegate) rather than route:
  treat this as auto-sorting the clear traffic, not full automation.
- Overlapping picklist labels cap accuracy (collecte_om vs selective is a
  label-space problem, not a model one).
- The escalate class was trained on 126 synthetic near-domain OOD examples
  (etat civil, factures, horaires, voirie, voisinage). It confidently
  delegates "boite aux lettres vandalisee"-type traffic; widen it with
  client-labeled negatives for your real OOD mix.
