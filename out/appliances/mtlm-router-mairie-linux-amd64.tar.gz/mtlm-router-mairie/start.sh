#!/bin/sh
# mtlm-router "mairie" appliance — collectivites request triage.
# One call returns route + confidence + complexity tier.
# Optional: ANVIL_WITH_NOUL=1 ./start.sh adds the experimental escalate
# signal (p_yes) — noisy on municipal French, validate on your data first.
# Usage: ./start.sh [port]   (default 8097)
cd "$(dirname "$0")"
PORT=${1:-8097}
if [ "$ANVIL_WITH_NOUL" = "1" ]; then
  ANVIL_HEAD=mairie.head ANVIL_SCORE=score.head ANVIL_NOUL=noul.head \
    exec ./anvil-serve models/model.bin $PORT
else
  ANVIL_HEAD=mairie.head ANVIL_SCORE=score.head \
    exec ./anvil-serve models/model.bin $PORT
fi
