#!/bin/sh
# mtlm-router appliance — start the server (no systemd needed).
# Env knobs: PORT (8097), ANVIL_ROUTE_MINCONF (0.55), ANVIL_GATE_MINCONF,
# ANVIL_POOL=max|mean, ANVIL_LOG (decisions.jsonl),
# ANVIL_DELEGATE_URL/KEY/MODEL/SYS (optional upstream for delegated requests).
cd "$(dirname "$0")"
PORT=${PORT:-8097}
export ANVIL_TOOLS_INJECT=0
export ANVIL_HEAD=models/m7router3s384.head ANVIL_NOUL=models/m7router3s384.noul.head ANVIL_SCORE=models/m7router3s384.score.head ANVIL_GATE=models/moe_gate.head ANVIL_EXPERTS=it_helpdesk:models/helpdesk_pool_L-3_mean.head,fleet_gate:models/machinfit_pool_L-3_max.head,rpg:models/rpg_pool_L-4_mean.head
export ANVIL_LOG=logs/decisions.jsonl
mkdir -p logs
echo "mtlm-router on http://0.0.0.0:$PORT  (logs: logs/decisions.jsonl)"
exec ./anvil-serve models/model.bin "$PORT"
