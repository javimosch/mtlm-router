#!/bin/sh
# Two-domain MoE demo: municipal requests vs smart-home intents, one trunk.
cd "$(dirname "$0")"
PORT=8097
./start.sh $PORT > demo.log 2>&1 &
PID=$!
trap 'kill $PID 2>/dev/null' EXIT
sleep 3

ask() {
  curl -s localhost:$PORT/v1/route -H 'Content-Type: application/json' \
    -d "{\"messages\":[{\"role\":\"user\",\"content\":\"$1\"}]}" | python3 -c "
import json,sys
d=json.load(sys.stdin)
print('  -> dom=%-7s gc=%.2f  route=%-20s conf=%.2f  %s' % (
    d.get('domain','-'), d.get('gate_confidence',0), d['route'], d['confidence'], d['action']))"
}

echo '=== mtlm-router MoE demo: 1 trunk, 1 gate (2.3KB), 2 expert heads ==='
echo
for q in "Dotation de bacs. Je souhaite un bac jaune supplementaire" \
         "Depot illicite. Des encombrants rue des Lilas" \
         "allume la lumiere du salon" \
         "mets de la musique" \
         "commande un taxi pour la gare" \
         "quel temps fera-t-il demain" \
         "je veux faire renouveler mon passeport"; do
  printf '%s\n' "$q"; ask "$q"
done
echo
echo 'One forward pass per request: gate -> domain, expert -> route.'
