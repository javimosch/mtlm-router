# mtlm-router — two-domain MoE demo appliance

One frozen ~7M-param trunk + a 2.3KB domain gate + per-domain expert heads.
Self-hosted, CPU-only, no external calls.

## Requirements

- Linux x86-64, glibc, libssl3 (stock Debian/Ubuntu/RHEL works)
- ~30MB disk, <512MB RAM, no GPU
- `curl` + `python3` for demo.sh pretty-printing (optional)

## Install & run

Everything needed is in this tarball — the anvil-serve binary, the model
(models/model.bin), the tokenizer, and all head files. Nothing to install,
no model download, no license server.

    tar xzf mtlm-router-moe-demo-linux-amd64.tar.gz
    cd mtlm-router-moe-demo
    ./start.sh        # listens on :8097
    ./demo.sh         # boots + fires a mixed-domain battery

## How it works

/v1/route does ONE forward pass, then two linear-head decisions on the same
hidden state:

1. `gate_domains.head` (2.3KB) picks the domain — 99.3% holdout separating
   mairie (municipal requests, French production data) vs iot (smart-home
   intents, MASSIVE fr-FR).
2. the matching expert head picks the route: mairie.head (15 lanes +escalate,
   79% holdout) or massive_fr_m4m.head (60 intents, 65% holdout).

Response: {"domain","gate_confidence","route","confidence","tier","action"}.

## Why this matters

- Per-domain heads are 18-70KB. A new client/domain = a new .head file
  trained on their labeled export — the trunk never changes.
- Add a third domain by extending ANVIL_EXPERTS and retraining the gate.
- Domains can also be pinned per API key (ANVIL_TENANTS) or by the caller
  (expert field) for known-context deployments.

## Honest limits

- The iot head (65% at 60-way) is a benchmark probe, not production grade —
  included to show multi-domain mechanics. Client-distribution heads do
  better (mairie: 79%).
- Gate confusions can happen at domain boundaries; they degrade to
  delegate/escalate, not silent misroutes.
