#!/bin/sh
# mtlm-router MoE demo — one frozen trunk, a domain gate, two expert heads.
# /v1/route: gate picks the domain (mairie|iot), expert picks the route.
# Usage: ./start.sh [port]   (default 8097)
cd "$(dirname "$0")"
PORT=${1:-8097}
ANVIL_HEAD=mairie.head \
ANVIL_GATE=gate_domains.head \
ANVIL_EXPERTS="mairie:mairie.head,iot:massive_fr_m4m.head" \
ANVIL_SCORE=score.head \
  exec ./anvil-serve models/model.bin $PORT
