#!/bin/sh
# mtlm-router appliance v0.2.0 — mhd3 multi-tap heads, batched pooled prefill.
# Env knobs: PORT (8097), ANVIL_ROUTE_MINCONF (0.55), ANVIL_LOG (decisions.jsonl)
cd "$(dirname "$0")"
PORT=${PORT:-8097}
export ANVIL_TOOLS_INJECT=0
export ANVIL_HEAD=models/decide_mt.head ANVIL_NOUL=models/noul_mt.head ANVIL_SCORE=models/score_mt.head ANVIL_GATE=models/gate_biz_mt.head
export ANVIL_EXPERTS=it_helpdesk:models/helpdesk_pool_L-3_mean.head,mairie:models/mairie_mt3.head,mairie_c:models/mairie_mt3c.head
export ANVIL_LOG=logs/decisions.jsonl
mkdir -p logs
echo "mtlm-router on http://0.0.0.0:$PORT  (logs: logs/decisions.jsonl)"
exec ./anvil-serve models/model.bin "$PORT"
