# mtlm-router appliance v0.2.0

Self-hosted typed decision layer — 7M-param router + mhd3 multi-tap decision
heads, pure MFL. Linux x86_64, no GPU, ~15-30ms per decision.

## Run

    ./start.sh                 # systemd-free, binds 0.0.0.0
    # or the agent-first CLI wrapper (loopback by default):
    ./mtlm-router serve                    # foreground, 127.0.0.1:8097
    ./mtlm-router daemon start|stop|status # detached + health-polled
    ./mtlm-router guide                    # embedded manual (JSON)
    ./mtlm-router feedback "msg" -kind bug  # report issues (dual-write, never fails)
    ./mtlm-router update                   # content-hash self-update (verify+smoke+atomic swap)
    ./mtlm-router install                  # copy CLI to ~/.local/bin
    ./mtlm-router feedback "msg" -kind bug  # report issues (dual-write, never fails)
    ./mtlm-router update                   # content-hash self-update (verify+smoke+atomic swap)
    ./mtlm-router install                  # copy CLI to ~/.local/bin
    # or: cp mtlm-router.service ~/.config/systemd/user/ && systemctl --user start mtlm-router

## Use

    curl localhost:8097/v1/route -H 'content-type: application/json' \
        -d '{"state":"remind me to call the dentist tomorrow","execute":true}'
    # {"action":"tool_call","route":"set_reminder","confidence":0.99,...}

Pin a domain expert (skips the gate):

    curl localhost:8097/v1/route -d '{"state":"depot illicite rue des lilas","expert":"mairie"}'
    curl localhost:8097/v1/route -d '{"state":"defaut collecte. bac gris non vide","expert":"mairie_c"}'

## Honest eval (leak-free protocol, live runtime)

| head | holdout |
|---|---|
| decide (16 routes) | 98.4% live |
| noul (escalation) | 99.4% live |
| score (complexity) | 98.8% live |
| gate (3 domains) | 98.7% live |
| mairie (16 municipal routes) | 81.5% live |
| mairie_c (merged collecte pair) | 90.7% live, 85% auto @ 98.1% |

manifest.json has sha256 for every artifact. Docs: github.com/javimosch/mtlm-router